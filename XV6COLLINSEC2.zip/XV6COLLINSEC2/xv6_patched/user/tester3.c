#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"

int
main(int argc, char *argv[])
{

printf(1,"Number of times there has been a system call: %d\n", PartB());

exit();

}
